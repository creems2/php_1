<?php

namespace App\Models;

use App\Models\Model;

class Event extends Model {
    protected string $table = 'event';
}