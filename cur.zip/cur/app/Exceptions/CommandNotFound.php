<?php

namespace App\Exceptions;

use Exception;

class CommandNotFound extends Exception
{

}
