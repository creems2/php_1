<?php

namespace App\Database;

use PDO;

abstract class Db extends PDO
{
}